package com.onkar.SpringDataJPAInJobPortal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaInJobPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaInJobPortalApplication.class, args);
	}

}
