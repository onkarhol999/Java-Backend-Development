package com.onkar.Question_Reminder_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionReminderBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
