package com.onkar.Question_Reminder_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionReminderBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestionReminderBackendApplication.class, args);
	}

}
