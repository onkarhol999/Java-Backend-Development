package com.onkar.QuizMicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
