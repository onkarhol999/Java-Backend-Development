package com.onkar.Student_App_Docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentAppDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
