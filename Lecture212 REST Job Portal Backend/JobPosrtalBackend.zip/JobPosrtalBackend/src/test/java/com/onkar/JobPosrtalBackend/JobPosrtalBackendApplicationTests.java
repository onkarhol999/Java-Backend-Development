package com.onkar.JobPosrtalBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPosrtalBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
