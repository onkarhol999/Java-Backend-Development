package com.Onkar.SpringBootLecture161;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLecture161ApplicationTests {

	@Test
	void contextLoads() {
	}

}
