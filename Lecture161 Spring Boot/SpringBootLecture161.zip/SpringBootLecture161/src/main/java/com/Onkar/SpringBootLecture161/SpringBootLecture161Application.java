package com.Onkar.SpringBootLecture161;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLecture161Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLecture161Application.class, args);
	}

}
