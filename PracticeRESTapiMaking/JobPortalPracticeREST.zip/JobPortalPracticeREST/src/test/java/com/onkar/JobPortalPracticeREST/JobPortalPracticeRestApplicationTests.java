package com.onkar.JobPortalPracticeREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalPracticeRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
