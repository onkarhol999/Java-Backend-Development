package com.onkar.firstDockerProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstDockerProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
