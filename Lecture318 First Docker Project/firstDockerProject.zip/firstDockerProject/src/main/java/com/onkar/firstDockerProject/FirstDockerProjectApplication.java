package com.onkar.firstDockerProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstDockerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstDockerProjectApplication.class, args);
	}

}
