package com.onkar.SpringJPAPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaPracticeApplication.class, args);
	}

}
