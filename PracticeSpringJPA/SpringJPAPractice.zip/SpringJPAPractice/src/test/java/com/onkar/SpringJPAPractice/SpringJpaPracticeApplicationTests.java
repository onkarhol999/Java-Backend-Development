package com.onkar.SpringJPAPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
