package com.onkar.spring_security_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
