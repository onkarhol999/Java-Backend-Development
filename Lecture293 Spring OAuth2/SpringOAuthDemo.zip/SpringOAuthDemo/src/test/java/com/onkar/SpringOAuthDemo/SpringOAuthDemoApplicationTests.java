package com.onkar.SpringOAuthDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringOAuthDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
