package com.onkar.SpringBootExternalJDBC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExternalJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
