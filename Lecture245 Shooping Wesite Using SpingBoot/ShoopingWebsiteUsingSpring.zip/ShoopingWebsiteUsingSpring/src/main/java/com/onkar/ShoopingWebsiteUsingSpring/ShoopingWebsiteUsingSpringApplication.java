package com.onkar.ShoopingWebsiteUsingSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoopingWebsiteUsingSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoopingWebsiteUsingSpringApplication.class, args);
	}

}
