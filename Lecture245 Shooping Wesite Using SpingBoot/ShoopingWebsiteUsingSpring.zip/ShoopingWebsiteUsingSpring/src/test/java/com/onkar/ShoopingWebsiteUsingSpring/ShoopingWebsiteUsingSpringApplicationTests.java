package com.onkar.ShoopingWebsiteUsingSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoopingWebsiteUsingSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
